| mode | images | active s / image | clicks / object | recall | precision | IoU (TP) |
| --- | --- | --- | --- | --- | --- | --- |
| assisted | 16 | 59.03 ± 29.65 | 0.65 ± 0.51 | 0.63 ± 0.31 | 0.39 ± 0.24 | 0.69 ± 0.03 |
| manual | 16 | 162.73 ± 125.19 | 6.33 ± 0.64 | 0.62 ± 0.16 | 0.55 ± 0.24 | 0.67 ± 0.04 |

Participants with both modes: 4. Mean active time per image: manual 162.7 s, assisted 59.0 s (**64% less time** with assistance).
Paired Wilcoxon signed-rank test on per-participant means: p = 0.125 (n = 4, a pilot study, not proof).

| detector version | suggested | accepted | rejected | acceptance rate |
| --- | --- | --- | --- | --- |
| v3 | 558 | 355 | 0 | 0.636 |
