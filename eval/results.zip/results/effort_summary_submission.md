| mode | images | active s / image | clicks / object | recall | precision | IoU (TP) |
| --- | --- | --- | --- | --- | --- | --- |
| assisted | 84 | 60.97 ± 46.98 | 0.90 ± 1.19 | 0.70 ± 0.17 | 0.61 ± 0.15 | 0.73 ± 0.04 |

| detector version | suggested | accepted | rejected | acceptance rate |
| --- | --- | --- | --- | --- |
| v3 | 358 | 326 | 0 | 0.911 |
| v4 | 506 | 286 | 0 | 0.565 |
| v5 | 1079 | 740 | 0 | 0.686 |
